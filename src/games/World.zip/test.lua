print(Script.name)

print("Making/setting color...")
local clr = LuaFactory.make("Color", 238, 238, 0, 123)
--World.element.head.color = clr

print("Setting coords, size, and stuff...")
local coords = LuaFactory.make("Vector", -8, 10, 5)
local color = LuaFactory.make("Color", 0, 0, 0, 255)
local size = LuaFactory.make("Vector", 4, 4, 2)

print("Making a brick...")

local a = ElementFactory.make("brick", "TestBrick", coords, color, size)
World.add_element(a)
print("Brick made!")
