print(Script.name)

World.element.head.set_rgb(238, 238, 0, 123)

local coords = {-8, 10, 5}
local color = {0, 0, 0, 255}
local size = {4, 4, 2}

local a = ElementFactory.make("brick", "TestBrick", coords, color, size)
World.add_element(a)

local x = os.time()

while os.difftime(os.time(), x) ~= 3 do

end

print("Removing TestBrick...")

World.remove_element("TestBrick")
