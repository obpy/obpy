-- Seed the random number generator - we'll use it later on
math.randomseed(os.time())

-- The number of seconds we let each snowflake exist before we remove it
SNOWFLAKE_LIFETIME = 25

-- This variable keeps track of how many snowflakes have been created so far
num_snowflakes = 0

-- This variable keeps track of all our snowflakes. We'll use it later on, in prune_snowflakes()
snowflakes = {}


function wait(amount)
   -- This function pauses its script for "amount" seconds

   local current_time = os.time()

   while os.difftime(os.time(), current_time) < amount do
      -- Do nothing
      -- This also gives other parts of OpenBlox a chance to run
      Script.scheduler.step()
   end

end


function prune_snowflakes()
   -- This function removes all snowflakes that have been around for "SNOWFLAKE_LIFETIME" seconds or longer

   for snowflake_name in pairs(snowflakes) do

      snowflake_creation_time = snowflakes[snowflake_name]

      print("Name: " .. snowflake_name)
      print("Creation time: " .. snowflake_creation_time)

      current_time = os.time()

      print("Lifetime: " .. os.difftime(current_time, snowflake_creation_time))

      -- Has the snowflake existed for too long?
      if os.difftime(current_time, snowflake_creation_time) >= SNOWFLAKE_LIFETIME then
      
         print("Removing " .. snowflake_name)

         -- Remove the snowflake
         World.remove_element(snowflake_name)

         -- Delete the snowflake's record from our "snowflakes" table, so we won't consider deleting it again.
         -- Imagine if we tried to delete a non-existent snowflake!
         snowflakes[snowflake_name] = nil
         
      end

   end         

end


function make_snow()
   -- This function makes a new snowflake

   num_snowflakes = num_snowflakes + 1
   print("Snowflakes: " .. num_snowflakes)

   -- RGBA(255, 255, 255, 255) is opaque white
   local color = LuaFactory.make("Color", 255, 255, 255, 255)

   -- We make all snowflakes start at a constant height, but we mix up their X/Y positions a little
   local coords = LuaFactory.make("Vector", math.random(-50, 50), math.random(-50, 50), 30)

   -- Make the smallest brick possible in OpenBlox 0.6.2
   local size = LuaFactory.make("Vector", 1, 1, 1)

   -- Give this snowflake a name
   local name = "Snowflake " .. num_snowflakes

   -- Create the snowflake, and add it to our world
   local brick = ElementFactory.make("brick", name, coords, color, size)
   World.add_element(brick)

   -- Record our snowflake's name, and creation time, so prune_snowflakes() can remove it
   -- when necessary
   snowflakes[name] = os.time()

end

-- Loop forever
while true do

   -- We don't want to make snowflakes too fast!
   wait(0.1)
   -- Make a new snowflake, and prune the existing ones
   make_snow()
   prune_snowflakes()

end
