-- Seed the random number generator - we'll use it later on
math.randomseed(os.time())

-- The number of seconds we let each snowflake exist before we remove it
SNOWFLAKE_LIFETIME = 25

-- The rate in seconds at which we remove old snowflakes and possibly add
-- new ones. For example, with the default value of 0.3, we check for
-- old snowflakes and possibly add new ones 0.3 times a second.
UPDATE_RATE = 0.3

-- This variable keeps track of how many snowflakes have been created so far
num_snowflakes = 0

-- This table keeps track of all our snowflakes. We'll use it later on, in prune_snowflakes()
snowflakes = {}


function prune_snowflakes()
   -- This function removes all snowflakes that have been around for "SNOWFLAKE_LIFETIME" seconds or longer

   for snowflake_name in pairs(snowflakes) do

      snowflake_creation_time = snowflakes[snowflake_name]
      current_time = os.time()

      -- Has the snowflake existed for too long?
      if os.difftime(current_time, snowflake_creation_time) >= SNOWFLAKE_LIFETIME then

         -- Remove the snowflake
         World.remove_element(snowflake_name)

         -- Delete the snowflake's record from our "snowflakes" table, so we won't consider deleting it again.
         -- Imagine if we tried to delete a non-existent snowflake!
         snowflakes[snowflake_name] = nil
         
      end
   end         
end


function make_snow()
   -- This function makes a new snowflake

   num_snowflakes = num_snowflakes + 1

   -- RGBA(255, 255, 255, 255) is opaque white
   local color = LuaFactory.make("Color", 255, 255, 255, 255)

   -- We make all snowflakes start at a constant height, but we mix up their X/Y positions a little
   local coords = LuaFactory.make("Vector", math.random(-50, 50), math.random(-50, 50), 30)

   -- Make the smallest brick possible in OpenBlox 0.6.2
   local size = LuaFactory.make("Vector", 1, 1, 1)

   -- Give this snowflake a unique name. Unique names isn't necessary in OpenBlox 0.7 and up, however
   local name = "Snowflake " .. num_snowflakes

   -- Create the snowflake, and add it to our world
   local brick = ElementFactory.make("brick", name, coords, color, size)
   World.add_element(brick)

   -- Record our snowflake's name, and creation time, so prune_snowflakes() can remove it
   -- when necessary
   snowflakes[name] = os.time()

end


function update_simulation(task)

   prune_snowflakes()
   make_snow()

   -- Returning task.AGAIN signals to our controlling task
   -- to run this function again. If we wanted our task to
   -- terminate, we'd return task.STOP instead.
   return task.AGAIN
end


-- Here, we create a task, and add it to our script's task scheduler. What is a task?
-- Well, tasks are a simple way to execute code (possibly repeatedly) at some point
-- in the future. You'll notice if you add a "print" statement after the
-- call to Script.scheduler.add(), and a "print" statement in the
-- update_simulation() function, the former will execute first!

-- The primary use of tasks in OpenBlox is repeatedly calling functions, since
-- OpenBlox runs a single Lua script at a time (for security and stability reasons)
-- a "while true do <xxx> end" wouldn't work - in fact, it would hang OpenBlox.

--                                     Function          Call rate  Priority  Name
task = LuaFactory.make("PeriodicTask", update_simulation, UPDATE_RATE, 0, 'snow_task')
Script.scheduler.add(task)
