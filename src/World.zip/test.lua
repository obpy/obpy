print(Script.name)
World.element.head.set_rgb(238, 238, 0, 123)