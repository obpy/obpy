#!/bin/sh

python tools/oblauncher.py